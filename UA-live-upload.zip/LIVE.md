# UA · Live

`live.php` ist die neue UA-Statistik. Der Link **UA** steht in `stats.php`. Die Seite nutzt die vorhandene Stats3-Anmeldung und das gemeinsame helle/dunkle Farbschema. **Live** ist verfügbar, **UserAgents** ist als späterer Bereich sichtbar.

## Anzeigen und Zeiträume

- 24-Stunden-Liniendiagramm: Unique User und Impressionen in genau 24 aufeinanderfolgenden 60-Minuten-Intervallen. Die Intervalle beginnen am Start des rollenden 24-Stunden-Fensters. Die Stundenwerte sind zusätzlich als aufklappbare Tabelle erreichbar.
- Live-Puls: zurückliegende zwei Minuten in 5-Sekunden-Intervallen; einzelne Seitenaufrufe schlagen nach oben aus, der erste gespeicherte Seitenaufruf einer Besucherkennung nach unten. Bei sehr hohen Zahlen überlagern sich die Ausschläge; Zahlen und Intervall-Tooltips zeigen weiterhin die tatsächliche Anzahl.
- Runder roter Pushover-Knopf: ein Aufleuchten pro neu bestätigter Nachricht, auch wenn mehrere in einem Abruf eintreffen. Bereits beim Öffnen vorhandene Meldungen blinken nicht erneut. Klicken öffnet Mind. Bei reduzierter Bewegung bleibt die Textmeldung erhalten und die Blinkfolge entfällt.
- Fünf jüngste Seitenaufrufe mit vollständiger URL als Text, inklusive Protokoll, Port und Query. Auf dem Telefon dürfen lange URLs umbrechen.
- Kampagnentabelle nach Quelle **und** Name, mit Suche und zehn Kennzahlen in der gewünschten Reihenfolge.

„Tag“ bedeutet seit heute 00:00 Uhr Europe/Berlin; „Stunde“ die laufende Kalenderstunde; „24h“ die letzten 86.400 Sekunden. Sommer-/Winterzeit wird bei den Tages- und Stundengrenzen berücksichtigt. Der Zeitpunkt der Abfrage ist die exklusive Obergrenze; Ereignisse aus derselben Sekunde erscheinen spätestens beim nächsten Abruf.

Alle Anzeigen laden alle fünf Sekunden neu. Es laufen keine überlappenden Requests. Im Hintergrund und beim Pausieren stoppt die Abfrage; beim Fortsetzen wird neu geladen. Bei einem Verbindungsfehler bleiben die letzten Werte mit sichtbarem Zeitstempel und Fehlermeldung stehen. Bei abgelaufener Anmeldung stoppt das Polling und bietet einen Login-Link an.

## Zählung und Datenquellen

Impressionen sind `stat4_events.event_type = 'pageview'`, einschließlich erneuter Aufrufe. Technische Heartbeats, Klicks und erkannte Bots aus `stat4_sessions`/`stat4_visitors` werden ausgeschlossen. Besucher werden über unterschiedliche STAT4-Besucherkennungen innerhalb des jeweiligen Fensters gezählt. Für die neuen User im Puls wird geprüft, ob es schon einen früher gespeicherten Seitenaufruf derselben Kennung gibt.

Kampagnen stammen aus `stat4_sessions.utm_source` und `utm_campaign`. Die Sitzung darf vor dem betrachteten Fenster begonnen haben. Verschiedene Seiten sind Host und Pfad, ohne Query/Fragment; die Groß-/Kleinschreibung des Pfades bleibt relevant. User einer Kampagne sind keine addierbaren Anteile der Gesamt-User, weil derselbe User mehreren Kampagnen begegnen kann.

Pushover-Zahlen kommen aus den bestätigten Mind-Sendungen und aus `stat4_notifications` mit `status = 'sent'`. Teilnachrichten zählen einzeln. STAT4-Milestones aus Mind und STAT4 werden zusammengeführt; die importierten Mind-Historienkopien zählen nicht zusätzlich. Fehlende Versandtabellen erzeugen einen sichtbaren Hinweis zur unvollständigen Datenquelle. Die Anzeige löst keine Pushover-Sendung aus.

Für die Zuordnung einer STAT4-Sendung wird die letzte gespeicherte Pageview-Sitzung dieses Users vor dem Versand verwendet. Stats3-Sendungen verwenden die Kampagnenparameter der zugehörigen gespeicherten Seiten-URL. Fehlt eine belastbare Zuordnung, erscheinen sie in der eigenen Zeile **(nicht zuordenbar)**. Die verschiedenen Besucherhashes der beiden Tracker werden nicht miteinander gleichgesetzt.

## Upload

Diese Dateien gemeinsam relativ zum Stats3-Verzeichnis hochladen:

1. `live.php`
2. `live_data.php`
3. `live.css`
4. `live.js`
5. `stats.php`
6. `pixl_server.php`
7. `stat4/db.php`
8. `stat4/collect.php`
9. `pixl_schema.sql`
10. `stat4/schema.sql`

Die Schemas ergänzen `stat4_events.page_url` für neue Installationen. Bei einer bestehenden Installation ergänzt der aktualisierte STAT4-Collector die nullable TEXT-Spalte beim nächsten Ereignis einmalig und speichert danach die bereits im bestehenden Payload übermittelte URL. Dafür braucht der vorhandene Datenbanknutzer wie bei den anderen Schemaergänzungen `ALTER`-Rechte. Der Bericht selbst liest nur und legt keine Tabellen oder Spalten an. JavaScript-Tracker und private Konfiguration brauchen für diese Ergänzung keine Änderung.

Alte Zeilen bleiben erhalten; unbekannte Protokolle und Ports werden nicht rückwirkend erfunden. Solche Zeilen erscheinen mit Host/Pfad und einem sichtbaren Hinweis, bis sie aus der Liste der letzten fünf Aufrufe fallen.

## Lokale Prüfung

`composer test-live` prüft Zeitgrenzen, URL-Verarbeitung und Login-Rücksprung ohne Datenbankzugriff. Für echte MySQL-/HTTP-Prüfungen `PIXL_LIVE_TEST_DSN` auf eine **leere, ausschließlich für Tests angelegte `pixl_setup_test_*`-Datenbank** setzen; optional `PIXL_LIVE_TEST_USER` und `PIXL_LIVE_TEST_PASSWORD`. Die Tests verwenden niemals die konfigurierte Besucher-Datenbank.

Mit `PIXL_LIVE_TEST_BROWSER=1` folgen Chromium-Prüfungen für Fünf-Sekunden-Polling, Blinkfolgen, Ausfälle, Authentifizierung, Suche, Textsicherheit, leere Daten, acht Bildschirmbreiten und Dark Mode. `CHROME_PATH`/`PLAYWRIGHT_MODULE` können die lokale Browserinstallation überschreiben, `PIXL_LIVE_ARTIFACTS` bestimmt den Screenshot-Ordner. Die Browser-Verhaltenstests nutzen markierte Testantworten; die Datenbankabfragen und der Collector werden zuvor separat über echtes MySQL und HTTP geprüft.

Es werden keine echten Benachrichtigungen versendet. Lokale Prüfungen ersetzen weder den FTP-Upload noch eine Live-Prüfung auf dem Server.
